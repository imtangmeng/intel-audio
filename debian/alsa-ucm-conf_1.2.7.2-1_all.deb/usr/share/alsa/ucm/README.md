Use Case Configuration files v1 syntax
--------------------------------------

This directory holds old UCM configuration files. The new
configuration files should be created in the ucm2 tree only.
